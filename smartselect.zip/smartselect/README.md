SmartSelect is a browser extension that provides context-aware options to users when they select text on a webpage. With SmartSelect, users can select text and choose from a variety of options to interact with the selected text.

SmartSelect utilizes an API from OpenAI to perform actions on the selected text. The extension currently supports the following actions:

Rewrite the Tweet
Create Reply
Option 1
Option 2
SmartSelect automatically detects the website domain and provides the corresponding options based on the predefined options map.

